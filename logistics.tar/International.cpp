#include "International.h"

International::International() {
	// TODO - implement International::International
	//throw "Not yet implemented";
}

International::~International() {
	// TODO - implement International::~International
	//throw "Not yet implemented";
}

void International::mode() {
	cout<<"The containers are being shiped to the meat and they carry:"<<endl;
	getCarry()->show();
}
