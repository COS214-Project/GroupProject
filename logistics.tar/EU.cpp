#include "EU.h"

EU::EU(){
	// TODO - implement EU::EU
	//throw "Not yet implemented";
}

EU::~EU() {
	// TODO - implement EU::~EU
	//throw "Not yet implemented";
}

void EU::mode() {
	cout<<"The truck are being driven to the meat and they carry:"<<endl;
	getCarry()->show();
}
