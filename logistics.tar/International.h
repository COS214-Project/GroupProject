#ifndef INTERNATIONAL_H
#define INTERNATIONAL_H

#include "Continent.h"
using namespace std;

class International : public Continent {


public:
	International();

	~International();

	void mode();
};

#endif
