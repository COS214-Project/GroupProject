#ifndef EU_H
#define EU_H

#include "Continent.h"
using namespace std;

class EU : public Continent {


public:
	EU();

	~EU();

	void mode();
};

#endif
